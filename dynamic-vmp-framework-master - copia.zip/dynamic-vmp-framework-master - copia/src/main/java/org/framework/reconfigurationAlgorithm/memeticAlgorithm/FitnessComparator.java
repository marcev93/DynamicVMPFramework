package org.framework.reconfigurationAlgorithm.memeticAlgorithm;

/**
 * @author Leonardo Benitez.
 */
public interface FitnessComparator {

     int compare(Individual individual1, Individual individual2);
}
