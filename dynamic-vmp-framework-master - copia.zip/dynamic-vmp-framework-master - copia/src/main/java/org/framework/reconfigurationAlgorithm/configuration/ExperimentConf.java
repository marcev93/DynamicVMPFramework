package org.framework.reconfigurationAlgorithm.configuration;

/**
 * ExperimentConf
 */
public class ExperimentConf {

    public static Float OVERLOAD_PM_THRESHOLD = 90F;
    public static Float UNDERLOAD_PM_THRESHOLD = 10F;


}
