package org.framework.reconfigurationAlgorithm.memeticAlgorithm;

/**
 * @author Leonardo Benitez.
 */
public class LocalSearch {

    public static Population localImprovement(Population population){


        return population;
    }

}
